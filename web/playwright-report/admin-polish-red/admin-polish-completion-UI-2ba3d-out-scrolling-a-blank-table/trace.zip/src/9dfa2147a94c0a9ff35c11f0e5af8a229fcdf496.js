import { test, expect } from '@playwright/test';
import { resetDemo, login } from './demoHelpers.js';
test('UI-COMP-A13 mobile appeal empty state is readable without scrolling a blank table', async ({ page }) => {
  await resetDemo(page);
  await page.setViewportSize({ width: 390, height: 900 });
  await login(page, 'admin', '/admin/appeals');
  const message = page.getByText('Chưa có kháng cáo. Hồ sơ người dùng gửi sẽ xuất hiện tại đây.', { exact: true });
  await expect(message).toBeVisible();
  const bounds = await message.boundingBox();
  expect(bounds.x).toBeGreaterThanOrEqual(0);
  expect(bounds.x + bounds.width).toBeLessThanOrEqual(390);
});
test('MASTER Admin notification opens a private actionable message', async ({ page }) => {
  await resetDemo(page);
  await login(page, 'admin', '/admin/dashboard');
  await page.getByRole('button', { name: 'Thông báo', exact: true }).click();
  await expect(page.getByText('Thông báo', { exact: true }).last()).toBeVisible();
});
