import { test, expect } from '@playwright/test';
import { resetDemo, login } from './demoHelpers.js';
test('UI-COMP-S02 mobile chat launcher does not cover the post-class primary action', async ({ page }) => {
  await resetDemo(page);
  await page.setViewportSize({ width: 390, height: 900 });
  await login(page, 'minhanh', '/learner/post-class');
  const primary = page.getByRole('button', { name: /Tiếp tục/ });
  await expect(primary).toBeVisible();
  const usable = await primary.evaluate(button => {
    const r = button.getBoundingClientRect();
    return [.15, .5, .85, .97].every(fraction => [.15, .5, .85].every(vertical => {
      const hit = document.elementFromPoint(r.left + r.width * fraction, r.top + r.height * vertical);
      return hit === button || button.contains(hit);
    }));
  });
  expect(usable, 'Every section of the primary action should accept its own clicks, including the right edge').toBe(true);
});

test('UI-COMP-S02 mobile chat launcher avoids controls after scrolling and changing form step', async ({ page }, testInfo) => {
  await resetDemo(page);
  await page.setViewportSize({ width: 390, height: 844 });
  await login(page, 'minhanh', '/learner/post-class');
  for (const step of [1, 2]) {
    const primary = page.getByRole('button', { name: /Tiếp tục/ });
    await primary.scrollIntoViewIfNeeded();
    await expect.poll(() => primary.evaluate(button => {
      const r = button.getBoundingClientRect();
      return [.15, .5, .85, .97].every(horizontal => [.15, .5, .85].every(vertical => {
        const hit = document.elementFromPoint(r.left + r.width * horizontal, r.top + r.height * vertical);
        return hit === button || button.contains(hit);
      }));
    })).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`post-step-${step}-launcher.png`) });
    await primary.click();
  }
  await expect(page.getByRole('heading', { name: 'Bước 3: Ngân sách và Mục tiêu' })).toBeVisible();
});
