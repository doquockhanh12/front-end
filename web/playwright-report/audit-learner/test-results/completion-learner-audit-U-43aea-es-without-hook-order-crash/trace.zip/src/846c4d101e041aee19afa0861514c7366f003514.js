import { test, expect } from '@playwright/test';
import { createDemoState, DOMAIN_STORAGE_KEY } from '../../src/features/domain/demoDomain.js';
import { resetDemo, login, fixedTime } from './demoHelpers.js';

const seed = () => createDemoState(fixedTime);
async function stateOf(page) {
  return page.evaluate(key => JSON.parse(localStorage.getItem(key)), DOMAIN_STORAGE_KEY);
}
async function setup(page, state = seed(), user = null) {
  await resetDemo(page, { state, ...(user ? {user} : {}) });
  if (user) await page.goto('/learner/dashboard');
  else await login(page, 'minhanh', '/learner/dashboard');
}

test('UI-COMP-L01 floating chat opens Messages without hook-order crash', async ({page}) => {
  await setup(page);
  const errors=[]; page.on('pageerror', error => errors.push(error.message));
  await page.getByRole('button', {name:'Mở cửa sổ trò chuyện'}).click();
  await page.getByRole('button', {name:'Mở toàn màn hình'}).click();
  await expect(page).toHaveURL(/\/messages$/);
  await expect(page.getByRole('textbox', {name:'Nội dung tin nhắn'})).toBeVisible();
  expect(errors).toEqual([]);
});

test('UI-COMP-L02 secondary learner cannot see another account class posts or conversations', async ({page}) => {
  const state=seed(); const user=state.users.find(u=>u.id==='user-learner-active-2');
  await setup(page,state,user);
  await page.goto('/learner/my-classes');
  await expect(page.getByText('MÃ LỚP: #post-101', {exact:true})).toHaveCount(0);
  await page.goto('/messages');
  await expect(page.locator('.chat-thread-item')).toHaveCount(0);
});

test('UI-COMP-L02 learner schedule only shows owned lesson IDs, not unowned history', async ({page}) => {
  await setup(page);
  await page.goto('/learner/schedule');
  const ownedCount=seed().lessons.filter(l=>l.learnerId==='demo-learner').length;
  await expect(page.locator('.lesson-card')).toHaveCount(ownedCount);
});

test('UI-COMP-L03 completed lesson cannot be cancelled by learner', async ({page}) => {
  await setup(page); await page.goto('/learner/schedule');
  await page.getByRole('button', {name:/Đã hoàn thành/}).click();
  await page.getByRole('button', {name:'Chi tiết & Hủy lịch'}).first().click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.getByRole('button', {name:'Hủy buổi học này'})).toHaveCount(0);
});

test('UI-COMP-L04 refund without linked escrow never consumes unrelated class escrow', async ({page}) => {
  await setup(page); await page.goto('/learner/schedule');
  await page.getByRole('button', {name:'Chi tiết & Hủy lịch'}).first().click();
  const before=await stateOf(page);
  await page.getByRole('button', {name:'Yêu cầu Hoàn tiền 100% vì Sự cố'}).click();
  const after=await stateOf(page);
  expect(after.escrowTransactions).toEqual(before.escrowTransactions);
  expect(after.wallets).toEqual(before.wallets);
});

test('UI-COMP-L05 insufficient balance cannot mark offer deposit successful', async ({page}) => {
  const state=seed();state.wallets['demo-learner'].availableBalance=0;
  await setup(page,state);await page.goto('/messages');
  await page.getByRole('button',{name:'Đồng ý & Đặt cọc ngay'}).click();
  await expect(page.getByText('Đã đồng ý & Đặt cọc thành công',{exact:true})).toHaveCount(0);
  expect((await stateOf(page)).messages.find(m=>m.type==='custom_offer').offerData.status).toBe('pending');
});

test('UI-COMP-L06 paid offer produces linked shared lessons visible to Tutor', async ({page}) => {
  await setup(page); await page.goto('/messages');
  const before=await stateOf(page);const offer=before.messages.find(m=>m.type==='custom_offer');
  await page.getByRole('button',{name:'Đồng ý & Đặt cọc ngay'}).click();
  const after=await stateOf(page);
  const newEscrow=after.escrowTransactions.find(e=>!before.escrowTransactions.some(old=>old.id===e.id));
  expect(newEscrow,'Successful payment must create canonical escrow').toBeTruthy();
  expect(after.lessons.filter(l=>l.escrowId===newEscrow.id||l.offerId===offer.id||l.messageId===offer.id)).toHaveLength(offer.offerData.sessionsCount);
});

test('UI-COMP-L07 lesson modal supports keyboard Escape and focus return', async ({page}) => {
  await setup(page);await page.goto('/learner/schedule');
  const trigger=page.getByRole('button',{name:'Chi tiết & Hủy lịch'}).first();
  await trigger.click();await expect(page.getByRole('dialog')).toBeVisible();
  await expect.poll(()=>page.getByRole('dialog').evaluate(el=>el.contains(document.activeElement))).toBe(true);
  await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(trigger).toBeFocused();
});

test('UI-COMP-L08 proposal profile agrees with canonical public tutor university', async ({page}) => {
  await setup(page);await page.goto('/learner/my-classes');
  const profile=seed().profiles.find(p=>p.id==='quoc-bao');
  const candidate=page.locator('.myclass-proposal-card').filter({hasText:'Trần Gia Bảo'});
  await expect(candidate).toContainText(profile.university);
});

test('UI-COMP-L09 newly submitted class awaits Admin moderation', async ({page}) => {
  await setup(page);await page.goto('/learner/post-class');
  await page.getByRole('button',{name:'Tiếp tục: Địa điểm & Lịch học'}).click();
  await page.getByRole('button',{name:'Tiếp tục: Ngân sách & Mục tiêu'}).click();
  const before=await stateOf(page);
  await page.getByRole('button',{name:/Đăng tin|Gửi tin/}).last().click();
  await expect(page).toHaveURL(/\/learner\/my-classes$/);
  const created=(await stateOf(page)).classPosts.find(p=>!before.classPosts.some(old=>old.id===p.id));
  expect(created).toBeTruthy();expect(created.moderationStatus).toBe('pending');
});

test('UI-COMP-L10 selected candidate provides a deposit next step before claiming matched class', async ({page}) => {
  await setup(page);await page.goto('/learner/my-classes');
  const candidate=page.locator('.myclass-proposal-card').filter({hasText:'Trần Gia Bảo'});
  await candidate.getByRole('button',{name:'Chọn gia sư này'}).click();
  await expect(page.getByRole('button',{name:/Đặt cọc/}).or(page.getByRole('link',{name:/Đặt cọc/}))).toBeVisible();
});
