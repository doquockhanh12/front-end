import { test, expect } from '@playwright/test';
import { resetDemo, login } from './demoHelpers.js';
test('UI-COMP-S02 mobile chat launcher does not cover the post-class primary action', async ({ page }) => {
  await resetDemo(page);
  await page.setViewportSize({ width: 390, height: 900 });
  await login(page, 'minhanh', '/learner/post-class');
  const primary = page.getByRole('button', { name: /Tiếp tục/ });
  await expect(primary).toBeVisible();
  const usable = await primary.evaluate(button => {
    const r = button.getBoundingClientRect();
    return [.15, .5, .85, .97].every(fraction => [.15, .5, .85].every(vertical => {
      const hit = document.elementFromPoint(r.left + r.width * fraction, r.top + r.height * vertical);
      return hit === button || button.contains(hit);
    }));
  });
  expect(usable, 'Every section of the primary action should accept its own clicks, including the right edge').toBe(true);
});
