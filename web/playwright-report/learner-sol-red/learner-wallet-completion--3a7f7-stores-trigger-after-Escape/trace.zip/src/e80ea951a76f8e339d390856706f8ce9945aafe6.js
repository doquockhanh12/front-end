import { test, expect } from '@playwright/test';
import { resetDemo, login } from './demoHelpers.js';

test('UI-COMP-L15 wallet modal traps focus and restores trigger after Escape', async ({ page }) => {
  await resetDemo(page); await login(page, 'minhanh', '/learner/wallet');
  const trigger = page.getByRole('button', { name: 'Nạp tiền VietQR Napas 247', exact: true });
  await trigger.click();
  const dialog = page.getByRole('dialog');
  await expect.poll(() => dialog.evaluate(node => node.contains(document.activeElement))).toBe(true);
  await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0); await expect(trigger).toBeFocused();
});

test('Learner local QR demonstration credits chosen amount once after three seconds without banking request', async ({ page }) => {
  const bankingRequests = [];
  page.on('request', request => { if (/vietqr\.io|napas/i.test(request.url())) bankingRequests.push(request.url()); });
  await resetDemo(page); await login(page, 'minhanh', '/learner/wallet');
  const balance = await page.evaluate(() => JSON.parse(localStorage.getItem('tnm.demo.domain.v1')).wallets['demo-learner'].availableBalance);
  await page.getByRole('button', { name: 'Nạp tiền VietQR Napas 247', exact: true }).click();
  await page.getByLabel('Số tiền nạp').fill('200000');
  await expect(page.getByRole('dialog')).toContainText('Không chuyển tiền thật');
  await page.clock.fastForward(3000);
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.getByRole('status')).toContainText('200.000');
  await page.clock.fastForward(6000);
  const state = await page.evaluate(() => JSON.parse(localStorage.getItem('tnm.demo.domain.v1')));
  expect(state.wallets['demo-learner'].availableBalance).toBe(balance + 200000);
  expect(bankingRequests).toEqual([]);
});

test('Learner QR demo rejects invalid amount and cancellation prevents a deposit', async ({ page }) => {
  await resetDemo(page); await login(page, 'minhanh', '/learner/wallet');
  const balance = await page.evaluate(() => JSON.parse(localStorage.getItem('tnm.demo.domain.v1')).wallets['demo-learner'].availableBalance);
  await page.getByRole('button', { name: 'Nạp tiền VietQR Napas 247', exact: true }).click();
  await page.getByLabel('Số tiền nạp').fill('-1');
  await page.clock.fastForward(4000); await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.getByRole('alert')).toContainText('50.000');
  await page.getByLabel('Số tiền nạp').fill('200000'); await page.keyboard.press('Escape');
  await page.clock.fastForward(4000);
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem('tnm.demo.domain.v1')).wallets['demo-learner'].availableBalance)).toBe(balance);
});
