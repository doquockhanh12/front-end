import { test, expect } from '@playwright/test';
import { createDemoState, DOMAIN_STORAGE_KEY } from '../../src/features/domain/demoDomain.js';
import { resetDemo, login, fixedTime } from './demoHelpers.js';

test('TUTOR-FLOW share trip opens a functional local demo view and stays within mobile bounds', async ({ page }) => {
  await page.setViewportSize({width:390,height:844});
  await resetDemo(page); await login(page,'giabao','/tutor/timetable');
  await page.getByRole('button',{name:'Chia sẻ buổi dạy',exact:true}).first().click();
  const dialog=page.getByRole('dialog',{name:'Chia sẻ hành trình dạy học cho người thân'});
  const link=dialog.getByLabel('Liên kết demo buổi dạy');
  await expect(link).toHaveValue(/\/safety\/trip\?lesson=/);
  const box=await dialog.boundingBox(); const copy=await dialog.getByRole('button',{name:'Sao chép',exact:true}).boundingBox();
  expect(copy.x+copy.width).toBeLessThanOrEqual(box.x+box.width);
  await dialog.getByRole('link',{name:'Xem hành trình demo'}).click();
  await expect(page.getByRole('heading',{name:'Hành trình buổi dạy demo'})).toBeVisible();
  await expect(page.locator('main')).toContainText(/không.*GPS/i);
});

test('TUTOR-FLOW onboarding checklist and two student card images persist', async ({page})=>{
  await resetDemo(page); await login(page,'giabao','/tutor/profile');
  const image={name:'student-card.png',mimeType:'image/png',buffer:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j5ZkAAAAASUVORK5CYII=','base64')};
  await page.getByLabel('Ảnh mặt trước thẻ sinh viên').setInputFiles(image);
  await page.getByLabel('Ảnh mặt sau thẻ sinh viên').setInputFiles({...image,name:'student-card-back.png'});
  await page.getByRole('button',{name:'Gửi hồ sơ xác minh demo'}).click();
  await expect(page.getByRole('status')).toContainText('chờ Admin');
  await page.reload();
  await expect(page.getByRole('img',{name:'Mặt trước thẻ sinh viên'})).toBeVisible();
  await expect(page.getByRole('img',{name:'Mặt sau thẻ sinh viên'})).toBeVisible();
  await page.goto('/tutor/dashboard');
  await expect(page.getByLabel('Checklist hồ sơ gia sư')).toContainText('6/6');
});

test('TUTOR-FLOW pending application can be withdrawn and remains withdrawn on reload',async({page})=>{
  await resetDemo(page); await login(page,'giabao','/tutor/find-students');
  await page.getByRole('tab',{name:/Đơn ứng tuyển của tôi/}).click();
  const card=page.locator('.my-proposal-card').first();
  await card.getByRole('button',{name:'Rút đơn ứng tuyển'}).click();
  await expect(card).toContainText('Đã rút đơn'); await page.reload();
  await page.getByRole('tab',{name:/Đơn ứng tuyển của tôi/}).click();
  await expect(page.locator('.my-proposal-card').first()).toContainText('Đã rút đơn');
});

test('TUTOR-FLOW lesson progress, material and learner review persist through the shared domain',async({page})=>{
  const state=createDemoState(fixedTime);const lesson=state.lessons.find(l=>l.id==='seed-0');
  // Isolate learning/review behavior with the existing canonical learner identity.
  // Historical/operational lessons without learnerId cannot receive a review.
  const learner=state.users.find(u=>u.id==='demo-learner');
  lesson.learnerId=learner.id; lesson.learner=learner.fullName;
  await resetDemo(page,{state}); await login(page,'giabao','/tutor/timetable');
  await page.getByRole('button',{name:new RegExp(`${lesson.subject}.*${lesson.learner}`)}).click();
  const dialog=page.getByRole('dialog',{name:'Chi tiết lớp học'});
  await dialog.getByLabel('Nhận xét tiến độ buổi học').fill('Đã nắm chắc nội dung; luyện thêm bài tập.');
  await dialog.getByLabel('Tài liệu và bài tập buổi học').setInputFiles({name:'lesson.txt',mimeType:'text/plain',buffer:Buffer.from('Demo lesson material')});
  await dialog.getByRole('button',{name:'Lưu tiến độ và tài liệu'}).click();
  await expect(dialog.getByRole('link',{name:'lesson.txt'})).toBeVisible();
  await dialog.getByRole('button',{name:'Đánh dấu hoàn tất'}).click();
  await dialog.getByLabel('Đánh giá người học').selectOption('5');
  await dialog.getByLabel('Nhận xét về người học').fill('Người học tích cực và đúng giờ.');
  await dialog.getByRole('button',{name:'Gửi đánh giá người học'}).click();
  await expect(dialog).toContainText('Đã lưu đánh giá người học');
  const runtime=await page.evaluate(key=>JSON.parse(localStorage.getItem(key)),DOMAIN_STORAGE_KEY);
  const saved=runtime.lessons.find(l=>l.id===lesson.id);
  expect(saved.progress).toContain('Đã nắm chắc');expect(saved.materials[0].name).toBe('lesson.txt');
  expect(runtime.twoWayReviews.some(r=>r.lessonId===lesson.id)).toBe(true);
});
