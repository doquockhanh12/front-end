import { test, expect } from '@playwright/test';
import { resetDemo, login } from './demoHelpers.js';
import { createDemoState } from '../../src/features/domain/demoDomain.js';
import { fixedTime } from './demoHelpers.js';

test('Learner lesson downloads real attached content and can submit homework', async ({ page }) => {
  const state = createDemoState(fixedTime);
  const lesson = state.lessons.find(item => item.learnerId === 'demo-learner');
  lesson.materials = [{ name: 'assignment.txt', type: 'text/plain', dataUrl: 'data:text/plain;base64,bGVzc29u' }];
  await resetDemo(page, { state }); await login(page, 'minhanh', '/learner/schedule');
  await page.getByRole('button', { name: 'Chi tiết & Hủy lịch' }).first().click();
  const downloaded = page.waitForEvent('download');
  await page.getByRole('link', { name: 'Tải assignment.txt' }).click();
  expect((await downloaded).suggestedFilename()).toBe('assignment.txt');
  await page.getByLabel('Nộp bài tập').setInputFiles({ name: 'homework.txt', mimeType: 'text/plain', buffer: Buffer.from('Learner submission') });
  await expect(page.getByText('homework.txt', { exact: true })).toBeVisible();
});

test('Learner discovery preserves tutor map positions after sorting and filters by level', async ({ page }) => {
  await resetDemo(page); await login(page, 'minhanh', '/learner/search');
  await page.getByRole('button', { name: 'Bản đồ chia đôi', exact: true }).click();
  const pin = page.getByRole('button', { name: /Chọn Trần Gia Bảo,/ });
  const before = await pin.getAttribute('transform');
  await page.getByLabel('Sắp xếp').selectOption('price');
  expect(await pin.getAttribute('transform')).toBe(before);
  await page.getByRole('group', { name: 'Cấp độ học' }).getByLabel('THCS', { exact: true }).check();
  await expect(page.locator('.learner-split-list .tutor-card')).not.toHaveCount(0);
});

test('Learner post supports Mầm non and stores user-selected concrete session proposals', async ({ page }) => {
  await resetDemo(page); await login(page, 'minhanh', '/learner/post-class');
  await page.getByLabel('Khối lớp / Trình độ *').selectOption('Mầm non');
  await page.getByRole('button', { name: 'Tiếp tục: Địa điểm & Lịch học' }).click();
  await page.getByLabel('Ngày học mong muốn').fill('2026-10-08');
  await page.getByLabel('Giờ bắt đầu').fill('18:00');
  await page.getByRole('button', { name: 'Thêm buổi học' }).click();
  await page.getByRole('button', { name: 'Tiếp tục: Ngân sách & Mục tiêu' }).click();
  await page.getByRole('button', { name: /Đăng tin|Gửi tin/ }).last().click();
  await expect(page).toHaveURL(/my-classes$/);
  await expect(page.locator('.myclass-card').filter({ hasText: 'Mầm non' })).toContainText('08/10');
});
